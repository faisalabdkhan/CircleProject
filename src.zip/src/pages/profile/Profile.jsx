import "./profile.scss"

const Profile = () => {
  return (
    <div className='profile'>Profile</div>
  )
}

export default Profile
